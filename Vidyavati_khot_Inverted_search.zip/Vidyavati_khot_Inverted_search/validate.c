/***************************************************************************************************************************************************
* File         : file_validation.c
* Title        : To validate the input text files
* Description  : This function verifies each filename provided through the command-line before adding it to the
*                filename linked list. It performs multiple checks to ensure only valid, usable files are included
*                for building the inverted search database. The validations performed are:
*
*                1. Checks whether the file has a .txt extension.
*                2. Detects and rejects duplicate filenames.
*                3. Checks whether the file can be opened in read mode.
*                4. Verifies that the file is not empty.
*
*                If a file passes all validations, a new node is created and added to the filename linked list.
*                All invalid files are skipped with appropriate error messages displayed to the user.
*
*                Algorithm:
*                1. Initialize valid file counter to zero.
*                2. For each filename:
*                     - Check whether it ends with ".txt".
*                     - Check for duplicates among the remaining filenames.
*                     - Attempt to open the file in read mode.
*                     - Check whether the file size is greater than zero.
*                     - If all conditions pass, create a new fn_node and add it to the linked list.
*                3. After processing all filenames:
*                     - If no valid files were found, return FAILURE.
*                     - Else, return SUCCESS.
*
* Input        : filename_list[] - Array of filenames
*                file_count      - Number of filenames
*                fhead           - Pointer to the head pointer of the filename linked list
*
* Output       : Adds only valid .txt files into the filename linked list.
*                Returns SUCCESS if at least one valid file exists, otherwise FAILURE.
*
***************************************************************************************************************************************************/

#include "inverted.h"

/* Function for validating input files */
int file_validation(char *filename_list[], int file_count, fn_node **fhead)
{
    /* Defnition here */
    // count of valid files
    int valid = 0;

    for(int i = 0; i < file_count; i++)
    {
        char *filename = filename_list[i];

        /* Check for .txt extension */
        char *ext = strrchr(filename, '.');
        if(ext == NULL || strcmp(ext, ".txt") != 0)
        {
            printf("✘ ERROR : %s is not a .txt file\n", filename);
            continue;
        }

        /* Check for duplicates */
        int duplicate = 0;
        for(int j = i + 1; j < file_count; j++)
        {
            if(strcmp(filename, filename_list[j]) == 0)
            {
                printf("✘ ERROR : %s is a duplicate file\n", filename);
                duplicate = 1;
                break;
            }
        }
        if(duplicate)
            continue;

        /* Check if file opens */
        FILE *fp = fopen(filename, "r");
        if(fp == NULL)
        {
            printf("✘ ERROR : Cannot open file %s\n", filename);
            continue;
        }

        /* Check if the file is empty */
        fseek(fp, 0, SEEK_END);
        long size = ftell(fp);
        fclose(fp);

        if(size == 0)
        {
            printf("✘ ERROR : %s is empty\n", filename);
            continue;
        }

        /* 5. Add file to linked list */
        fn_node *new = malloc(sizeof(fn_node));
        strcpy(new->file_name, filename);
        new->link = *fhead;
        *fhead = new;

        printf("➡ file Added to linked list: %s\n", filename);
        valid++;
    }

    /* No valid files at all */
    if(valid == 0)
    {
        printf("✘ ERROR : No valid files found\n");
        return FAILURE;
    }

    return SUCCESS;
}
