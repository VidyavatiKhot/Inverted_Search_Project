#ifndef INVERTED_H
#define INVERTED_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define SUCCESS 1
#define FAILURE 0
#define TABLE_SIZE 27


// Structure for file list
typedef struct file_name
{
    char file_name[50];
    struct file_name *link;
}fn_node;


// Structure for link table / subnode
typedef struct subnode
{
    char file_name[50];
    int word_count;
    struct subnode *link;
}sub_node;


// Structure to store word count / mainnode
typedef struct mainnode
{
    char word[50];
    int file_count;
    struct mainnode *m_link;
    struct subnode *s_link;
}main_node;


/* Hash table declaration */
extern main_node *hash_table[TABLE_SIZE];


/* FUnction Prototypes for helper functions */

/* Hash function for dictionary indexing */
int hash_function(char *word);   

// Functio to Searches for a word in a linked list
main_node *search_word(main_node *head, char *word); 

// Function to Create a new main node
main_node *create_mainnode(char *word);  

// Function to Create a new subnode
sub_node *create_subnode(char *filename);   

// Function to Adds/updates file entry for a word
void insert_subnode(main_node *mnode, char *filename);  

// Function to insert word into hash table
void insert_word(char *word, char *filename);   



/* Function prototypes for main functions */

// Function declaration to read and validate input files
int file_validation(char *filename_list[], int file_count, fn_node **fhead);

// Function declaration for create database
void create_database(fn_node *file_head);

// Function declaration for display database
void display_database();

// Function declaration for search database
void search_database();

// Function declaration for save database
void save_database();

// Function declaration for update database
void update_database();


#endif

