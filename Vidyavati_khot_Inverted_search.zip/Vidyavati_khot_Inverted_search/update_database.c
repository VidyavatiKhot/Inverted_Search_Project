/***************************************************************************************************************************************************
* File         : update_database.c
* Title        : To update (rebuild) the database from the backup file
* Description  : This function reconstructs the inverted search database using the information stored 
*                inside "backup.txt". It is used when the user wants to restore the previous state 
*                of the inverted index without processing all the text files again.
*
*                Working:
*                1. Open the backup file ("backup.txt") in read mode.
*                2. Read each record from the file in the same format used by save_database():
*                     - Hash index
*                     - Word
*                     - File count
*                     - Filename and word count pairs
*                3. For every entry:
*                     a) Create a new main node if the word does not exist.
*                     b) Create subnodes for each filename and count.
*                     c) Insert them into the correct index of the hash table.
*                4. Continue reading and reconstructing until all lines are processed.
*                5. Close the backup file once the entire database is restored.
*
*                This function helps in:
*                - Loading previously saved data
*                - Avoiding re-reading original text files
*                - Quickly restoring the complete inverted index
*
* Input        : None (uses "backup.txt")
*
* Output       : Rebuilds the global hash_table with all words and file occurrences.
*                Prints a message once the update/restoration is complete.
*
****************************************************************************************************************************************************/

#include "inverted.h"

/* Function to update the database from backup file  */
void update_database()
{
    FILE *fp = fopen("backup.txt", "r");
    if(fp == NULL)
    {
        printf("✘ ERROR : Could not open backup file.\n");
        return;
    }

    // Clear old data
    for(int i = 0; i < TABLE_SIZE; i++)
        hash_table[i] = NULL;

    char line[200];

    // Read each line from backup.txt
    while(fgets(line, sizeof(line), fp))
    {
        // Break the line into pieces
        char *p = strtok(line, ";");
        if(p == NULL) 
            continue;

        // #index
        int index = atoi(p + 1);        

        char *word = strtok(NULL, ";");
        if(word == NULL) 
            continue;

        // how many files
        int file_count = atoi(strtok(NULL, ";")); 

        // Make main node for this word
        main_node *mnode = create_mainnode(word);
        mnode->file_count = file_count;

        // For each file under this word
        for(int i = 0; i < file_count; i++)
        {
            char *fname = strtok(NULL, ";");
            char *str_count = strtok(NULL, ";");

            if(fname == NULL || str_count == NULL)
                break;

            int count = atoi(str_count);

            // create subnode
            sub_node *s = create_subnode(fname);
            s->word_count = count;

            // attach subnode
            s->link = mnode->s_link;
            mnode->s_link = s;
        }

        // put main node inside hash table
        mnode->m_link = hash_table[index];
        hash_table[index] = mnode;
    }

    fclose(fp);
    printf("✔ Database Updated Successfully.\n");
}
