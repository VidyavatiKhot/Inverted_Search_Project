/***************************************************************************************************************************************************
* File         : save_database.c
* Title        : To save the database into a backup file
* Description  : This function saves the entire inverted search database into a backup file. 
*                The output is stored in a structured format so that the database can be restored 
*                later using the update operation.
*
*                Working:
*                1. Open a file named "backup.txt" in write mode.
*                2. Traverse all TABLE_SIZE (26) hash indexes.
*                3. For each main node (unique word) in that index:
*                     - Write:
*                          a) Hash index
*                          b) Word
*                          c) Number of files containing the word (file_count)
*                     - For each subnode in the main node:
*                          * Write the filename and the count of occurrences
*                4. Data is stored in a consistent delimited format to allow easy reading 
*                   during update_database().
*                5. Close the file after writing all entries.
*
* Input        : None (uses global hash_table)
*
* Output       : Creates / overwrites "backup.txt" containing the entire inverted index.
*                Prints a success message after saving.
*
****************************************************************************************************************************************************/

#include "inverted.h"

/* Function to save the database to backup file */
void save_database()
{
    /* Defnition here */

    //open backup file
    FILE *fp = fopen("backup.txt", "w");
    if(fp == NULL)
    {
        printf("✘ ERROR : Could not open backup file.\n");
        return;
    }

    //Traverse the hash table
    for(int i = 0; i < TABLE_SIZE; i++)
    {
        main_node *mtemp = hash_table[i];

        while(mtemp != NULL)
        {
            fprintf(fp, "# %d; %s; %d; ", i, mtemp->word, mtemp->file_count);

            sub_node *stemp = mtemp->s_link;

            while(stemp != NULL)
            {
                fprintf(fp, "%s; %d; ", stemp->file_name, stemp->word_count); 
                stemp = stemp->link; 
            } 
            fprintf(fp, "#\n"); 
            
            mtemp = mtemp->m_link; 
        } 
    } 
    fclose(fp); 
    printf("\n✔ Database saved successfully to backup.txt\n");
}