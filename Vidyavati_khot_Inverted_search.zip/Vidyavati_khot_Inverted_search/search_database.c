/***************************************************************************************************************************************************
* File         : search_database.c
* Title        : To search for a word in the database
* Description  : This function allows the user to search for any word stored in the inverted index.
*                The word is taken as input from the user, hashed to find the correct index, and then
*                searched within the linked list of that index. If the word exists, its file occurrence
*                details are displayed from the subnode list.
*
*                Working:
*                1. Prompt the user to enter a word to search.
*                2. Compute the hash index using hash_function().
*                3. Traverse the main node list in that index:
*                     - If a match is found, print:
*                          a) The word
*                          b) Number of files containing the word
*                          c) Each file's name and its individual word count
*                     - If the main node is not found, the word does not exist.
*                4. If the word is not found in the table, print a message indicating that the word
*                   is not present in any file.
*
* Input        : Word entered by the user (via stdin)
*
* Output       : Prints:
*                - Word not found message
*                OR
*                - Word found message with:
*                     * number of files
*                     * filename list
*                     * count of occurrences in each file
*
****************************************************************************************************************************************************/

#include "inverted.h"

/* Function to search a word in the database */
void search_database()
{
    /* Defnition here */

    char word[50];
    printf("Enter the word to search:");
    scanf("%s", word);

    //get an index
    int index = hash_function(word);
 
    main_node *mtemp = hash_table[index];

    while(mtemp != NULL)
    {
        if(strcmp(mtemp->word, word) == 0)
        {
            printf("\n✔ Word '%s' found!\n", word);
            printf("➡ Appears in %d file(s) : \n", mtemp->file_count);

            sub_node *stemp = mtemp->s_link;
            while(stemp != NULL)
            {
                printf("%s : %d times\n", stemp->file_name, stemp->word_count);
                stemp = stemp->link;
            }
            return;
        }
        mtemp = mtemp->m_link;
    }
    printf("\n✘ Word '%s' not found in the database.\n", word);
}