/***************************************************************************************************************************************************
* File         : display_database.c
* Title        : To display the database
* Description  : This function displays the complete inverted index (hash table) in a structured format.
*                It traverses all 26 hash table indexes (A–Z dictionary style). For each index, it prints
*                all main nodes (unique words) and their associated subnodes (filenames and word counts).
*
*                Working:
*                1. Loop through all TABLE_SIZE (26) hash indexes.
*                2. If the current index contains one or more main nodes:
*                     - Print the index.
*                     - For each main node:
*                         a) Print the word.
*                         b) Print the number of files containing that word (file_count).
*                         c) Traverse its subnode list and print:
*                               - filename
*                               - number of occurrences in that file
*                3. Continue until all indexes and nodes are printed.
*
*                This function acts like printing a dictionary:
*                Index A → all words starting with ‘A’
*                Index B → all words starting with ‘B’
*                ...
*                Index Z → all words starting with ‘Z’
*
* Input        : None (uses global hash_table)
*
* Output       : Prints the inverted search database in a readable table-like format.
*
****************************************************************************************************************************************************/

#include "inverted.h"

/* Function to display the hash table content */
void display_database()
{
    /* Defnition here */
    printf("\n======================================================================\n"); 
    printf("\033[1m%5s | %-16s | %-10s | %-15s | %-5s\033[0m\n", "Index", "Word", "File Count", "Filename", "Count");
    printf("\n======================================================================\n");

    for(int i = 0; i < TABLE_SIZE; i++)
    {
        main_node *m_temp = hash_table[i];
        if(m_temp == NULL)
            continue;

        while(m_temp != NULL)
        {
            sub_node *s_temp = m_temp->s_link;
            int first = 1;

            while(s_temp != NULL)
            {
                if(first)
                {
                    // For special characters index
                    if(i == 26)
                        printf("  SC  | %-16s | %-10d | %-15s | %-5d\n",
                               m_temp->word, m_temp->file_count, s_temp->file_name, s_temp->word_count);
                    else
                    // Print full row for first subnode
                        printf("%5d | %-16s | %-10d | %-15s | %-5d\n",
                           i, m_temp->word, m_temp->file_count, s_temp->file_name, s_temp->word_count);

                    first = 0;
                }
                else
                {
                    // Print additional file rows aligned properly
                    printf("      | %-16s | %-10s | %-15s | %-5d\n",
                           "", "", s_temp->file_name, s_temp->word_count);
                }

                s_temp = s_temp->link;
            }

            printf("\n======================================================================\n");
            m_temp = m_temp->m_link;
        }
    }
}
