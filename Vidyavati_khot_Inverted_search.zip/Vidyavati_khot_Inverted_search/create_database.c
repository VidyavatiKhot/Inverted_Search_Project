/***************************************************************************************************************************************************
* File         : create_database.c
* Title        : To create the database
* Description  : This function reads every file name stored in the file list linked list and constructs the
*                inverted search database. For each file, every word is extracted and inserted into the hash
*                table using insert_word(). If a word already exists, its count is updated. If not, a new
*                main node is created. A subnode is created for each file in which the word occurs. The
*                hash table works like a dictionary with 26 indexes (A–Z), and words are grouped based on
*                their first character.
*
*                Algorithm:
*                1. Traverse the linked list of filenames.
*                2. Open each file in read mode.
*                3. Read words one by one using fscanf().
*                4. For each word:
*                     - Pass the word and filename to insert_word().
*                     - insert_word() hashes the word.
*                     - Word is inserted into appropriate hash index.
*                5. Continue until all files are processed.
*                6. Close all files and finish building the database.
*
* Input        : Pointer to the head of the filename linked list (fn_node *file_head)
*
* Output       : Populates the global hash table with all words and their file occurrence details.
*                Prints "Database created successfully!" upon completion.
*
****************************************************************************************************************************************************/

#include "inverted.h"

/* Function to create the inveretd index */
void create_database(fn_node *file_head)
{
    /* Defnition here */
    fn_node *temp = file_head;
    char word[50];

    while(temp != NULL)
    {
        FILE *fp = fopen(temp->file_name, "r");
        if(fp == NULL)
        {
            printf("✘ ERROR : Opening file %s\n", temp->file_name);
            temp = temp->link;
            continue;
        }

        //read each word from the file
        while(fscanf(fp, "%49s", word) != EOF)
        {
            insert_word(word, temp->file_name);
        }
        fclose(fp);
        temp = temp->link;
    }
    printf("✔ Database created successfully!\n");
}