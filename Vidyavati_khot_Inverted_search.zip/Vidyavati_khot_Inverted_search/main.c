/***************************************************************************************************************************************************
* File         : main.c
* Title        : Driver function
* Description  : This file contains the driver code for the Inverted Search project. It performs the 
*                following tasks:
*
*                1. Validates all input files passed through command line arguments.
*                2. Stores the valid filenames in a linked list.
*                3. Displays a menu-driven interface to the user with operations:
*                       - Create Database
*                       - Display Database
*                       - Search Database
*                       - Save Database
*                       - Update Database
*                       - Exit
*                4. Based on user choice, the respective functions are called.
*
*                The main function acts as the controller of the entire project, managing the workflow 
*                and coordinating all modules like validation, creation, searching, displaying, saving 
*                and restoring the inverted index.
*
****************************************************************************************************************************************************/

#include "inverted.h"

// Global hash table initialization to NULL
main_node *hash_table[TABLE_SIZE] = {NULL};

int main(int argc, char *argv[])
{
    /* Define the main function here */
    int choice;
    int db_created = 0;
    int db_updated = 0;
    int db_saved = 0;
    int second_create = 0;

    fn_node *file_head = NULL;

    // check if atleast 1 filename is provided
    if(argc < 2)
    {
        printf("USAGE : ./inverted.out file1.txt file2.txt ....\n");
        return FAILURE;
    }

    // validate all input files
    if(file_validation(&argv[1], argc - 1, &file_head) == FAILURE)
    {
        printf("✘ File validation failed, Exiting...\n");
        return FAILURE;
    }

    while(1)
    {
        printf("\n========== MENU ==========\n");
        printf("1 ➤  Create Database.\n");
        printf("2 ➤  Display Database.\n");
        printf("3 ➤  Search Database.\n");
        printf("4 ➤  Save Database.\n");
        printf("5 ➤  Update Database.\n");
        printf("6 ➤  Exit\n");
        printf("===========================\n");

        printf("Enter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
            case 1:
            {
                /* Function call to create inveretd index */
                if(db_created == 1 && db_updated == 0)
                {
                    printf("INFO : Database already created!\n");
                    break;
                }
                // database re-created after update
                if(db_updated == 1 && second_create == 1)
                {
                    printf("INFO: Database already re-created after update.\n");
                    break;
                }
            
                create_database(file_head);
                if(db_updated == 1)
                    second_create = 1;
                else
                    db_created = 1;

                db_saved = 0;
            
            }
            break;

            case 2:
            {
                /* Function call to Display database contents */
                //no database exist
                if(db_created == 0 && second_create == 0)
                {
                    printf("INFO : No database to display. Create first.\n");
                    break;
                }
                display_database();
            }
            break;
    
            case 3:
            {
                /* Function call to search a word */
                // cannot search without database
                if(db_created == 0 && second_create == 0)
                {
                    printf("INFO : No database to search.Create first.\n");
                    break;
                }
                search_database();
            }
            break;

            case 4:
            {
                /* Function call to save database to backup file */
                //if Database not created, cannot save
                if(db_created == 0 && second_create == 0)
                {
                    printf("INFO : No database to save. Create first\n");
                    break;
                }
                save_database();
                db_saved = 1;
            }
            break;

            case 5:
            {
                /* Function call to rebuild the database from backup */

                // update only once
                if(db_updated == 1)
                {
                    printf("INFO : Database allready updated!\n");
                    break;
                }

                // Cannot update before create
                if(db_created == 0 && second_create == 0)
                {
                    printf("INFO : Cannot update before creating database.\n");
                    break;
                }
                // must save before update
                if(db_saved == 0)
                {
                    printf("INFO : Please save the database before updating.\n");
                    break;
                }

                update_database();
                db_updated = 1;
                db_created = 0;
                second_create = 0;
                db_saved = 0;
            }
            break;

            case 6:
            {
                /* Exit the program */
                printf("Exiting...\n");
                exit(0);
            }
            default :
                printf("⚠ Invalid Choice!\n");
        }
    }

}