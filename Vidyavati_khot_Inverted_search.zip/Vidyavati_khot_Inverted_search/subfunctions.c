#include "inverted.h"

/*  
 * Function: hash_function
 * Description: Returns an index (0–25) based on the first character of the word.
 *              A/a → 0, B/b → 1, ..., Z/z → 25.
 * Input: word (char*)
 * Output: integer hash index
 */

/* Function for dictionary indexing */
int hash_function(char *word)
{
    char c = word[0];

    if(c >= 'A' && c <= 'Z')
        return c - 'A';

    if(c >= 'a' && c <= 'z')
        return c - 'a';

    // if not alphabet (numbers, symbols)
    return 26;
}


/*  
 * Function: create_mainnode
 * Description: Creates a new main node to store a unique word in the hash table.
 * Input: word (char*)
 * Output: Pointer to the newly created main_node
 */

/* Function for creating a main node */
main_node *create_mainnode(char *word)
{
    main_node *new = malloc(sizeof(main_node));
    strcpy(new->word, word);
    new->file_count = 0;
    new->m_link = NULL;
    new->s_link = NULL;
    return new;
}


/*  
 * Function: create_subnode
 * Description: Creates a new subnode to store filename and word count for a word.
 * Input: filename (char*)
 * Output: Pointer to the newly created sub_node
 */

/* Function for creating a subnode*/
sub_node *create_subnode(char *filename)
{
    sub_node *new = malloc(sizeof(sub_node));
    strcpy(new->file_name, filename);
    new->word_count = 1;
    new->link = NULL;
    return new;
}


/*  
 * Function: search_word
 * Description: Searches for a given word in the linked list of a specific hash index.
 * Input: head (main_node*), word (char*)
 * Output: Pointer to the main_node if found, otherwise NULL
 */

/* Function for searching a word in list */
main_node *search_word(main_node *head, char *word)
{
    while(head != NULL)
    {
        if(strcmp(head->word, word) == 0)
            return  head;
        head = head->m_link;
    }
    return NULL;
}


/*  
 * Function: insert_subnode
 * Description: Adds a new file entry to the main node or updates count if it already exists.
 * Input: mnode (main_node*), filename (char*)
 * Output: None
 */

/* Function for inserting new file entry to the main node */
void insert_subnode(main_node *mnode, char *filename)
{
    /* Defnition here */
    sub_node *temp = mnode->s_link;

    // file allready exist then update count
    while(temp != NULL)
    {
        if(strcmp(temp->file_name, filename) == 0)
        {
            temp->word_count++;
            return;
        }
        temp = temp->link;
    }

    // file not found, create new file entry
    sub_node *new = create_subnode(filename);
    new->link = mnode->s_link;
    mnode->s_link = new;
    mnode->file_count++;

}


/*  
 * Function: insert_word
 * Description: Inserts a word into the hash table. Creates main node/subnode if new,
 *              otherwise updates counts for existing word and file.
 * Input: word (char*), filename (char*)
 * Output: None
 */


/* Function to insert a word into the hash table */
void insert_word(char *word, char *filename)
{
    /* Definition here */

    // find index
    int index = hash_function(word);
    main_node *mnode = search_word(hash_table[index], word);

    //word allready exist
    if(mnode != NULL)
    {
        insert_subnode(mnode, filename);
        return;
    }
    // if word does not exist create a main node
    mnode = create_mainnode(word);

    //insert subnode
    insert_subnode(mnode, filename);

    //insert mainnode at head of hash table index
    mnode->m_link = hash_table[index];
    hash_table[index] = mnode;
}